package cmd

import (
	"bytes"
	"fmt"
	"os/exec"
)

func HandlePrint() error {
	output, err := create_archive()
	fmt.Println("The output value is:", output)
	fmt.Println("The err value is:", err)

	return err
}

func create_archive() (string, error) {

	archive_name := "test.tar.gz"
	cmd := exec.Command("tar", "zcf", archive_name, ".")
	
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr

	err := cmd.Run()

	if err != nil {
		return "", fmt.Errorf("Error: %v\n%s", err, stderr.String())
	}

	return stdout.String(), nil
}
